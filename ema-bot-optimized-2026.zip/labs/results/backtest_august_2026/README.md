# August 2026 MTD backtest — V2 balanced strategy

## Result

This is a frozen, point-in-time backtest from **2026-08-01 through 2026-08-26**,
the last complete session used by the run. It covered all **503 current S&P 500
constituents** and the exact SPY/sector proxies used by the scanner.

| Metric | Result |
|---|---:|
| Matured trades | 18 |
| Pending signals (excluded from P&L) | 6 |
| Winners / losers | 8 / 10 |
| Win rate | 44.44% |
| P&L at $500 per trade | +$66.36 |
| Return on summed trade allocations ($9,000) | +0.74% |
| Total R (where 1R = $5) | +13.27R |
| Profit factor | 1.72 |
| Average P&L per trade | +$3.69 |

All 18 matured trades were BUY signals. The best trade was AXON (+$39.23,
+7.85R); the worst was KHC (-$25.50, -5.10R). The sample is far too small to
draw a reliable conclusion from the reported annualized Sharpe ratio.

## Frozen rules

- Signal score at least 0.40; at most 10 signals per day, ranked across the full
  universe before fills.
- ADX hard minimum 18; 4-hour EMA slope magnitude minimum 0.003.
- 20-day average dollar volume between $25M and $1.5B.
- Daily signal uses only bars available through that signal date.
- Entry is the next trading session's unadjusted open.
- Exit is the close of the fifth trading session after the signal.
- Fixed $500 allocation per trade; no compounding.
- No transaction costs, slippage, spread, borrow fees, or execution failures.

## Anti-leakage and audit controls

- The parameters were taken from the production strategy before the August run;
  they were not optimized on August results.
- Daily and hourly histories include pre-August warm-up data. Hourly history is
  long enough to initialize the 200-period 4-hour EMA before the first signal.
- SPY plus XBI, XLB, XLC, XLE, XLF, XLI, XLK, XLP, XLRE, XLU, XLV, and XLY were
  present in both time frames.
- Signals without an observable five-session exit by August 26 are in
  `pending_signals.csv` and are excluded from performance.
- `audit.json` independently verifies source coverage, unique trade keys, score,
  ADX, liquidity and rank thresholds, next-open/fifth-session fills, direction-
  aware returns, USD P&L, R values, and aggregate totals. Status: **PASS**.

## Honest limitations

- The universe is today's S&P 500 membership, not historical membership as of
  each August date, so the run has survivorship bias.
- The live earnings-calendar and OpenInsider filters were excluded because no
  point-in-time archives were available. Applying today's event data to historical
  signals would introduce look-ahead bias.
- Prices are Yahoo chart OHLCV snapshots captured on 2026-08-27/28. The immutable
  cache hash and final ledger hash are recorded in `audit.json`; raw responses and
  the large cache are not included in this compact report package.
- This is one partial month and 18 matured trades, not evidence of durable edge.

## Files

- `trades.csv`: matured trade ledger used for P&L.
- `pending_signals.csv`: selected but not yet measurable signals.
- `selected_signals.csv`: all selected August signals and their status.
- `summary.json` and `monthly_2026.csv`: aggregates.
- `config.json`: frozen parameters.
- `audit.json`: independent validation and SHA-256 hashes.
