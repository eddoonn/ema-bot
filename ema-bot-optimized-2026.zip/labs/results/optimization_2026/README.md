# EMA strategy optimization — 2026 walk-forward report

## Decision

The production defaults were changed to:

- **7-session hold** instead of 5.
- **$100M–$750M** 20-session average dollar-volume eligibility instead of
  $25M–$1.5B.
- Keep the **0.40 score**, **ADX 18**, **0.003 4H slope**, **10/day cap**, and
  the existing **1.2 ATR gap guard**.
- Keep the three-calendar-day pre-earnings/report-day block, but set the
  post-earnings block to **0** so a new setup may qualify from the following
  session.
- Do **not** exclude Fridays, Mondays, weekends, or add tight percentage stops.
- Do **not** add Asia/London session rules: the source contains US regular-session
  bars only, so such a result would be fabricated.

`RANK_SCORE_VERSION` is now `v4`, preventing historical calibration from mixing
the old and new eligibility regimes.

## Walk-forward result

The candidate grid was learned on January–April, checked on May–June, evaluated
once on July, and finally compared with the already-observed August MTD period.
Core results deliberately do not apply retrospective earnings dates.

| Period | Baseline trades | Baseline R | Optimized trades | Optimized R | Baseline PF | Optimized PF |
|---|---:|---:|---:|---:|---:|---:|
| Jan–Apr training | 110 | +96.08 | 94 | **+202.72** | 1.54 | **2.18** |
| May–Jun validation | 23 | +38.58 | 18 | **+61.41** | 2.01 | **3.54** |
| July formal OOS | 23 | +2.62 | 16 | **+22.90** | 1.10 | **2.17** |
| August post-hoc | 18 | +13.27 | 14 | **+16.07** | 1.72 | **1.92** |

At $500 per trade and 1R = $5, August improves from +$66.36 to +$80.34. The
optimized August win rate is 64.29% (9/14). August is not a pristine holdout
because its original trades had already been reviewed.

## What the trades taught us

### Liquidity

The $750M–$1B average-dollar-volume bucket was the clearest weak pocket: 12
baseline trades lost 31.15R, with a 16.67% win rate and 0.18 profit factor. The
sub-$100M bucket was also negative, although it contained only four trades. A
simple contiguous $100M–$750M band was preferred over a complicated disjoint
filter; it improved training and validation quality and survived July OOS.

This remains a modest sample. The cap should be revisited after materially more
live trades rather than progressively narrowed around these observations.

### Holding period and stops

The benefit was a broad 7–10-session plateau, not a single isolated day. Seven
sessions gave the best training/validation balance and less tail exposure than
8–10 sessions. Tight 2%, 3%, and 4% stops reduced validation performance and
turned July negative, so they were rejected.

### Weekdays and weekends

Friday signals were strongest in the descriptive sample: 46 trades, +65.11R,
2.15 profit factor. A Friday exclusion damaged training and produced -1.42R in
July OOS. Monday was weaker overall, but a Monday exclusion was inconsistent
across splits. No weekday rule was promoted. Weekends already contain no US
cash sessions, so there is nothing additional to exclude.

### Earnings

Three original August trades were within the old three-before/two-after window:

- AXON before earnings: +2.18R.
- KHC before earnings: -5.10R.
- AXON two days after earnings: +7.85R.

A blanket post-earnings blackout discarded useful price-discovery setups. The
live rule now blocks the known lead-in and report date but allows the following
session. Historical reported dates from Nasdaq cover 498 of 503 symbols, but
they are retrospective and are **not** a point-in-time schedule archive. Their
performance is supplied as sensitivity analysis, not included in the core proof.

### Scores, ADX, repeat signals, and open gaps

- Raising the score floor to 0.45 improved average quality but reduced total R
  and was less convincing in August, so the user's 0.40 delivery floor remains.
- ADX 20/22 and a steeper 0.004 4H slope were inconsistent; keep 18/0.003.
- Suppressing overlapping same-symbol trades reduced total returns and did not
  hold up strongly enough to deploy.
- The existing 1.2 ATR signal-day gap guard affected almost no mature period
  trades. It remains as inexpensive tail protection; tighter 0.5 ATR gating was
  inconsistent.
- Next-open gap patterns were analyzed, but they were not promoted because the
  current webhook lifecycle does not support canceling an already-sent signal at
  the next open.

## Audit and limitations

- Audit status: **PASS**.
- 503/503 current S&P 500 constituents and every required SPY/sector proxy were
  present.
- 778 raw eligible candidate rows were reconstructed point-in-time.
- Every final trade was checked against the next-session open and seventh-
  subsequent-session close, including short-return direction and thresholds.
- Current index membership creates survivorship bias.
- No commissions, spread, slippage, borrow costs, or capacity effects are modeled.
- The strategy was tested on 2026 data only; the result is encouraging, not proof
  of a durable edge.
- Historical backtest trades were not sent to the live Discord channel.

## Files

- `final_walk_forward_comparison.csv`: baseline versus final rules by split.
- `final_trades_recommended_*.csv`: complete optimized ledgers for each split.
- `final_recommended_trades_all.csv`: combined optimized ledger.
- `hold_period_sweep.csv`: 2–10-session exit sensitivity.
- `single_factor_comparison.csv` and `by_*.csv`: filter diagnostics.
- `august_earnings_sensitivity.csv`: event-adjacent August trades.
- `final_report.json` and `final_audit.json`: machine-readable result and audit.
